/**
 *
 * @author Mbassip2
 */
public class Move {
    
    // Just a board square
    public int x;
    public int y;
    
    public Move(int i, int j){
        
    x= i;
    y= j;
    }
}
